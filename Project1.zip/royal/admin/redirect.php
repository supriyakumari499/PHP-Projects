<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		h3, h4{
			text-align: center;
		
		}
	</style>
</head>
<body>
	<h3>Room Unbooked Successfully......</h3>
	<h4><a href="rooms.php" >Click Here</a> </h4><h4> to go to main page .</h4>
</body>
</html>