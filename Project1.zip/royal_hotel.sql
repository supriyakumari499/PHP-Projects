-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2020 at 03:24 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `royal_hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `email` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('admin@gmail.com', 'admin12345');

-- --------------------------------------------------------

--
-- Table structure for table `double_ac`
--

CREATE TABLE `double_ac` (
  `s_no` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `holder_name` text NOT NULL,
  `holder_id` text NOT NULL,
  `holder_mobile` varchar(10) NOT NULL,
  `holder_address` text NOT NULL,
  `child` int(11) NOT NULL,
  `adult` int(11) NOT NULL,
  `in_date` date NOT NULL,
  `out_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `double_ac`
--

INSERT INTO `double_ac` (`s_no`, `room_no`, `holder_name`, `holder_id`, `holder_mobile`, `holder_address`, `child`, `adult`, `in_date`, `out_date`, `status`) VALUES
(1, 251, 'Rajvir', 'DO123', '7894561230', 'Ajmer', 0, 1, '2020-07-06', '2020-07-09', 1),
(2, 252, '', '', '', '', 0, 0, '0000-00-00', '0000-00-00', 0),
(3, 253, 'Meena', 'mn12345', '7845693210', 'kolapur', 0, 1, '0000-00-00', '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `double_non_ac`
--

CREATE TABLE `double_non_ac` (
  `s_no` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `holder_name` text NOT NULL,
  `holder_id` text NOT NULL,
  `holder_mobile` varchar(10) NOT NULL,
  `holder_address` text NOT NULL,
  `child` int(11) NOT NULL,
  `adult` int(11) NOT NULL,
  `in_date` date NOT NULL,
  `out_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `double_non_ac`
--

INSERT INTO `double_non_ac` (`s_no`, `room_no`, `holder_name`, `holder_id`, `holder_mobile`, `holder_address`, `child`, `adult`, `in_date`, `out_date`, `status`) VALUES
(1, 201, 'Mira Rajput', 'DOO123', '1023456789', 'Amirpur, Gujrat', 0, 1, '2020-07-05', '2020-07-10', 1),
(2, 202, '', '', '', '', 0, 0, '0000-00-00', '0000-00-00', 0),
(3, 203, '', '', '', '', 0, 0, '0000-00-00', '0000-00-00', 0),
(4, 204, '', '', '', '', 0, 0, '0000-00-00', '0000-00-00', 0),
(5, 204, 'Gurudev', '1245', '4561230789', 'Punjab', 0, 1, '2020-07-12', '2020-07-14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `single_ac`
--

CREATE TABLE `single_ac` (
  `s_no` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `holder_name` text NOT NULL,
  `holder_id` text NOT NULL,
  `holder_mobile` varchar(10) NOT NULL,
  `holder_address` text NOT NULL,
  `child` int(11) NOT NULL,
  `adult` int(11) NOT NULL,
  `in_date` date NOT NULL,
  `out_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `single_ac`
--

INSERT INTO `single_ac` (`s_no`, `room_no`, `holder_name`, `holder_id`, `holder_mobile`, `holder_address`, `child`, `adult`, `in_date`, `out_date`, `status`) VALUES
(1, 151, '', '', '', '', 0, 0, '0000-00-00', '0000-00-00', 0),
(2, 152, '', '', '', '', 0, 0, '0000-00-00', '0000-00-00', 0),
(3, 153, '', '', '', '', 0, 0, '0000-00-00', '0000-00-00', 0),
(4, 154, '', '', '', '', 0, 0, '0000-00-00', '0000-00-00', 0),
(5, 155, 'Radhika', 'AB123', '9654871230', 'Rajgir', 0, 0, '2020-06-11', '2020-07-24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `single_non_ac`
--

CREATE TABLE `single_non_ac` (
  `s_no` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `holder_name` text NOT NULL,
  `holder_id` text NOT NULL,
  `holder_mobile` varchar(10) NOT NULL,
  `holder_address` text NOT NULL,
  `child` text NOT NULL,
  `adult` text NOT NULL,
  `in_date` text NOT NULL,
  `out_date` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `single_non_ac`
--

INSERT INTO `single_non_ac` (`s_no`, `room_no`, `holder_name`, `holder_id`, `holder_mobile`, `holder_address`, `child`, `adult`, `in_date`, `out_date`, `status`) VALUES
(1, 101, 'Nandani Raj', 'NND123', '9876543210', 'puraini', '0', '1', '12-07-2020', '14-07-2020', 1),
(6, 102, 'mamta', 'mn123', '7854123069', 'goa', '0', '1', '12-03-2020', '15-03-2020', 1),
(8, 103, 'Ram', '12345', '4561230789', 'klio', '0', '1', '13-03-2020', '15-03-2020', 1),
(9, 104, 'Radha', '78945', '1230456987', 'haridwar', '0', '1', '14-02-2020', '15-02-2020', 1),
(10, 105, 'Naini', 'AB231', '1230456987', 'Patna', '0', '0', '2020-06-16', '2020-06-22', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `double_ac`
--
ALTER TABLE `double_ac`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `double_non_ac`
--
ALTER TABLE `double_non_ac`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `single_ac`
--
ALTER TABLE `single_ac`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `single_non_ac`
--
ALTER TABLE `single_non_ac`
  ADD PRIMARY KEY (`s_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `double_ac`
--
ALTER TABLE `double_ac`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `double_non_ac`
--
ALTER TABLE `double_non_ac`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `single_ac`
--
ALTER TABLE `single_ac`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `single_non_ac`
--
ALTER TABLE `single_non_ac`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
